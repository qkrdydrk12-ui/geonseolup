# 🔥 Firebase 연동 설정 가이드

## 1단계 — Firebase 프로젝트 생성

1. [https://console.firebase.google.com](https://console.firebase.google.com) 접속
2. **프로젝트 추가** 클릭
3. 프로젝트 이름 입력 (예: `geonseolup`)
4. Google 애널리틱스 → 선택 후 **프로젝트 만들기**

---

## 2단계 — 웹 앱 등록 및 설정값 복사

1. 프로젝트 홈 → **`</>`** (웹 아이콘) 클릭
2. 앱 닉네임 입력 후 **앱 등록**
3. 아래 형태의 **firebaseConfig** 값이 표시됨:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "geonseolup.firebaseapp.com",
  projectId: "geonseolup",
  storageBucket: "geonseolup.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

4. **이 값을 `firebase.js` 파일의 `FIREBASE_CONFIG` 부분에 붙여넣기**

---

## 3단계 — Firestore Database 생성

1. 좌측 메뉴 → **Firestore Database** → **데이터베이스 만들기**
2. **프로덕션 모드** 선택 → 위치: `asia-northeast3 (서울)` → **사용 설정**

---

## 4단계 — Firestore 보안 규칙 설정

1. Firestore → **규칙** 탭 클릭
2. 아래 규칙으로 교체 후 **게시**:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // 공고 목록: 누구나 읽기 / 관리자만 쓰기 (우선 모두 허용)
    match /jobs/{doc} {
      allow read: if true;
      allow write: if true;
    }

    // 신청 목록
    match /pending/{doc} {
      allow read: if true;
      allow write: if true;
    }

    // 설정
    match /settings/{doc} {
      allow read: if true;
      allow write: if true;
    }
  }
}
```

> ⚠️ 위 규칙은 개발/테스트용입니다.  
> 실서비스 운영 시에는 Firebase Authentication을 추가해 관리자만 쓰기 가능하도록 강화하세요.

---

## 5단계 — firebase.js 설정값 입력

`firebase.js` 파일을 열어서 `FIREBASE_CONFIG` 부분을 교체합니다:

```js
const FIREBASE_CONFIG = {
  apiKey:            "복사한 apiKey",
  authDomain:        "복사한 authDomain",
  projectId:         "복사한 projectId",
  storageBucket:     "복사한 storageBucket",
  messagingSenderId: "복사한 messagingSenderId",
  appId:             "복사한 appId"
};
```

---

## 6단계 — 배포 및 확인

1. Genspark **호스팅 배포** 탭 → **재배포**
2. 사이트 접속 → 공고 목록이 Firebase에서 로드되는지 확인
3. 관리자 페이지에서 공고 등록 → 다른 기기에서도 보이는지 확인 ✅

---

## 📋 Firestore 컬렉션 구조

| 컬렉션 | 설명 |
|---|---|
| `jobs` | 메인 공고 목록 |
| `pending` | 사용자 등록 신청 목록 |
| `settings` | 사이트 설정 값 |

---

## ❓ 무료 한도 (Spark 플랜)

| 항목 | 무료 한도 |
|---|---|
| 읽기 | 50,000건 / 일 |
| 쓰기 | 20,000건 / 일 |
| 저장 용량 | 1 GiB |
| 네트워크 | 10 GiB / 월 |

> 소규모 운영(하루 수백 명)은 무료 플랜으로 충분합니다.
