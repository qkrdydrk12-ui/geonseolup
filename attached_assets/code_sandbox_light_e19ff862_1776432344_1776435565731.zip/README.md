# 건설UP — 건설 현장 일자리 플랫폼

> 전국 건설 현장 일용직 구인정보 사이트 (Firebase Firestore 실시간 연동)

---

## 🌐 배포 URL

| 환경 | URL |
|------|-----|
| Genspark 호스팅 | https://e19ff862-3a6e-4ee4-92a0-a903a1d072c3.vip.gensparksite.com |
| Firebase 프로젝트 | geonseolup (asia-northeast3) |

---

## ✅ 완료된 기능

### 메인 (index.html)
- 실시간 일자리 목록 (Firebase Firestore `onSnapshot`)
- 직종/지역/급여 필터 + 정렬 (최신순, 급여 높은순·낮은순)
- 읽은 글 표시 (`localStorage` 기반, 최대 500개)
- 중복 공고 관리: 동일 연락처 최신글 상단 + 이전글 🔁 배지
- 유사 공고 🔍 배지 (Jaccard 유사도 ≥55% + 동일 지역 + 급여 ±20%)
- 자동 숨김 (등록 후 N시간 경과 → 메인 미노출, 관리자 설정)
- 모바일 최적화 헤더 + Web Share API 카카오 공유
- 광고 영역 (상단/피드 인터스티셜/하단)

### 구인 등록 (post.html)
- 사용자 직접 등록 폼 (제목/지역/직종/급여/숙식/연락처)
- 30분 쿨다운 제한 (같은 연락처 재등록 차단)
- 유사 글 감지 경고 모달 (차단 아님, 강행 가능)
- 자동 승인 / 관리자 검토 후 승인 선택 가능
- Firebase pending 컬렉션에 저장 → 관리자 승인 시 jobs로 이동

### 상세 페이지 (detail.html)
- Firebase에서 단건 조회 (`fbGetJob`)
- 비슷한 일자리 추천 알고리즘
- 전화/SMS 바로 연결

### 관리자 (admin.html)
- 로그인 (세션 기반)
- 공고 파싱 탭: 원문 텍스트 → 자동 구조화 파싱 후 등록
- 수동 등록 탭: 직접 입력 폼
- 목록 관리 탭: 숨기기/복원/삭제 + 상태 배지 (숨김/만료/이전중복/유사공고)
- 신청 관리 탭: 사용자 등록 신청 승인/거절
- 설정 탭: 관리자 검토 ON/OFF, 중복 공고 자동숨김 시간 설정, 광고 코드 관리, 문의 연락처 설정

---

## 🔥 Firebase 구성

### 컬렉션
| 컬렉션 | 설명 |
|--------|------|
| `jobs` | 메인 공고 목록 (관리자 등록 + 승인된 사용자 등록) |
| `pending` | 사용자 등록 신청 (미승인 포함) |
| `settings` | 사이트 설정값 (예약됨) |

### Firestore 보안 규칙
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /jobs/{doc}     { allow read: if true; allow write: if true; }
    match /pending/{doc}  { allow read: if true; allow write: if true; }
    match /settings/{doc} { allow read: if true; allow write: if true; }
  }
}
```

> ⚠️ 현재는 모든 읽기/쓰기 허용 설정입니다. 스팸 방지를 위해 나중에 IP 제한 또는 인증 규칙 추가를 권장합니다.

### localStorage 사용 항목 (Firebase 외 보조 저장)
| 키 | 용도 |
|----|------|
| `cj_viewed_jobs` | 읽은 공고 ID 목록 (최대 500개) |
| `cj_cooldowns` | 연락처별 등록 쿨다운 (30분) |
| `cj_admin_credentials` | 관리자 계정 정보 |
| `cj_admin_auth` | 로그인 세션 |
| `cj_auto_approve` | 자동 승인 설정 |
| `cj_dup_settings` | 자동숨김 시간 설정 |
| `cj_contact_*` | 문의 연락처 정보 |
| `cj_ad_*` | 광고 코드 |

---

## 📁 파일 구조

```
index.html       메인 일자리 목록 (Firebase 실시간 구독)
detail.html      공고 상세 페이지
post.html        사용자 구인글 등록
admin.html       관리자 페이지
firebase.js      Firebase 공통 모듈 (ES Module)
firebase-setup.md Firebase 설정 가이드
.replit          Replit 실행 설정
replit.nix       Nix 환경 설정
README.md        이 파일
```

---

## 🚀 배포 방법

### Genspark 재배포
1. 상단 **Hosting Deploy** 탭 클릭
2. **배포하기** 버튼 클릭
3. 배포 완료 후 URL 확인

### Replit 배포
1. 위 파일 7개 모두 업로드
2. Run 클릭 → `python3 -m http.server 8080` 자동 실행
3. Secrets에 환경변수 설정 불필요 (Firebase Config가 firebase.js에 포함됨)

### 가비아 도메인 연결 (Genspark)
1. Genspark → Hosting Deploy → Custom Domain → 도메인 입력
2. 가비아 DNS 관리 → CNAME 레코드 추가 (Genspark 제공 값)
3. DNS 전파 대기 (10분 ~ 48시간)

---

## 🔧 배포 후 필수 설정

1. `admin.html` 접속 → 비밀번호 변경
   - 기본 ID: `qkrdydrk12`
   - 기본 PW: `wns585426!@`
2. 설정 탭 → **구인 등록 검토 ON** 활성화 (부적절 글 방지)
3. 설정 탭 → 문의 연락처 등록 (이메일/카카오톡)
4. 광고 탭 → 애드센스 코드 삽입

---

## 🛣️ 향후 개선 권장사항

- [ ] Firestore 보안 규칙 강화 (인증 또는 쓰기 횟수 제한)
- [ ] 관리자 Firebase Authentication 연동
- [ ] 공고 만료 알림 (이메일/카카오 알림톡)
- [ ] 유료 공고 우선 노출 결제 시스템
- [ ] 구직자 프로필 등록 기능
- [ ] 실시간 알림 (새 공고 등록 시 Push)
