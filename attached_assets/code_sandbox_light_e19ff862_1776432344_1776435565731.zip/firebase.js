/**
 * ============================================================
 *  건설UP — Firebase 공통 모듈 (ES Module, Firestore v10 compat)
 *  모든 페이지에서 이 파일 하나만 수정하면 연동 완료
 * ============================================================
 *
 *  📌 Firebase 설정값 (이미 입력 완료)
 *  - 프로젝트: geonseolup
 *  - Firestore 규칙:
 *
 *     rules_version = '2';
 *     service cloud.firestore {
 *       match /databases/{database}/documents {
 *         match /jobs/{doc}       { allow read: if true; allow write: if true; }
 *         match /pending/{doc}    { allow read: if true; allow write: if true; }
 *         match /settings/{doc}   { allow read: if true; allow write: if true; }
 *       }
 *     }
 * ============================================================
 */

import { initializeApp }   from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
import {
  getFirestore,
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

/* ── 설정값 ── */
const FIREBASE_CONFIG = {
  apiKey:            'AIzaSyDBV9vioVA_Avbd0CGH7fMzCVZEYbG3UQM',
  authDomain:        'geonseolup.firebaseapp.com',
  projectId:         'geonseolup',
  storageBucket:     'geonseolup.firebasestorage.app',
  messagingSenderId: '762237788664',
  appId:             '1:762237788664:web:2db68aaef822c0f090360d',
  measurementId:     'G-H6W30S363W'
};

/* ── 초기화 ── */
const _app = initializeApp(FIREBASE_CONFIG);
const _db  = getFirestore(_app);

/* ── 컬렉션 참조 ── */
const JOBS_COL     = collection(_db, 'jobs');
const PENDING_COL  = collection(_db, 'pending');
const SETTINGS_COL = collection(_db, 'settings');

/* ============================================================
   공고(jobs) CRUD
  ============================================================ */

/** 전체 공고 로드 (최신순) */
export async function fbLoadJobs() {
  try {
    const snap = await getDocs(query(JOBS_COL, orderBy('date', 'desc')));
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {
    console.warn('[Firebase] fbLoadJobs 실패, localStorage 폴백:', e.message);
    return _localLoadJobs();
  }
}

/** 공고 실시간 구독 (index.html 메인 목록용) */
export function fbOnJobs(callback) {
  try {
    return onSnapshot(
      query(JOBS_COL, orderBy('date', 'desc')),
      snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }))),
      err  => {
        console.warn('[Firebase] onSnapshot 실패, localStorage 폴백:', err.message);
        callback(_localLoadJobs());
      }
    );
  } catch (e) {
    console.warn('[Firebase] fbOnJobs 실패, localStorage 폴백:', e.message);
    callback(_localLoadJobs());
    return () => {}; // unsubscribe noop
  }
}

/** 공고 단건 조회 */
export async function fbGetJob(id) {
  try {
    const snap = await getDoc(doc(_db, 'jobs', id));
    if (snap.exists()) return { id: snap.id, ...snap.data() };
  } catch (e) {
    console.warn('[Firebase] fbGetJob 실패:', e.message);
  }
  /* 폴백 — localStorage */
  return _localLoadJobs().find(j => j.id === id) || null;
}

/** 공고 추가 */
export async function fbAddJob(job) {
  try {
    const { id: _ignore, ...data } = job;
    const ref = await addDoc(JOBS_COL, { ...data, _createdAt: serverTimestamp() });
    return ref.id;
  } catch (e) {
    console.warn('[Firebase] fbAddJob 실패, localStorage 폴백:', e.message);
    _localSaveJob(job);
    return job.id;
  }
}

/** 공고 저장 (id 지정) */
export async function fbSetJob(id, job) {
  try {
    await setDoc(doc(_db, 'jobs', id), job, { merge: true });
  } catch (e) {
    console.warn('[Firebase] fbSetJob 실패:', e.message);
    _localSaveJob({ id, ...job });
  }
}

/** 공고 전체 배열 저장 (관리자 일괄 저장) */
export async function fbSaveJobs(jobs) {
  try {
    const existSnap = await getDocs(JOBS_COL);
    const existIds  = new Set(existSnap.docs.map(d => d.id));
    const newIds    = new Set(jobs.map(j => j.id));
    const promises  = [];

    /* 목록에 없는 공고 → hidden:true */
    existSnap.docs.forEach(d => {
      if (!newIds.has(d.id)) {
        promises.push(updateDoc(doc(_db, 'jobs', d.id), { hidden: true }));
      }
    });

    /* upsert */
    jobs.forEach(job => {
      const { id, ...data } = job;
      promises.push(setDoc(doc(_db, 'jobs', id), data, { merge: true }));
    });

    await Promise.all(promises);
  } catch (e) {
    console.warn('[Firebase] fbSaveJobs 실패, localStorage 폴백:', e.message);
    localStorage.setItem('construction_jobs', JSON.stringify(jobs));
  }
}

/** 공고 숨김 토글 */
export async function fbToggleHide(id, hidden) {
  try {
    await updateDoc(doc(_db, 'jobs', id), { hidden });
  } catch (e) {
    console.warn('[Firebase] fbToggleHide 실패:', e.message);
  }
}

/** 공고 삭제 (soft delete) */
export async function fbDeleteJob(id) {
  try {
    await updateDoc(doc(_db, 'jobs', id), { hidden: true, _deleted: true });
  } catch (e) {
    console.warn('[Firebase] fbDeleteJob 실패:', e.message);
  }
}

/* ============================================================
   신청(pending) CRUD
  ============================================================ */

/** 전체 신청 목록 로드 */
export async function fbLoadPending() {
  try {
    const snap = await getDocs(query(PENDING_COL, orderBy('_createdAt', 'desc')));
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {
    console.warn('[Firebase] fbLoadPending 실패, localStorage 폴백:', e.message);
    return _localLoadPending();
  }
}

/** 신청 추가 */
export async function fbAddPending(entry) {
  try {
    const { id: _ignore, ...data } = entry;
    const ref = await addDoc(PENDING_COL, {
      ...data,
      submittedAt: entry.date || new Date().toISOString(),
      _createdAt:  serverTimestamp()
    });
    return ref.id;
  } catch (e) {
    console.warn('[Firebase] fbAddPending 실패, localStorage 폴백:', e.message);
    _localSavePending(entry);
    return entry.id;
  }
}

/** 신청 상태 업데이트 (승인/거절) */
export async function fbUpdatePending(id, updates) {
  try {
    await updateDoc(doc(_db, 'pending', id), updates);
  } catch (e) {
    console.warn('[Firebase] fbUpdatePending 실패:', e.message);
  }
}

/** 신청 삭제 */
export async function fbDeletePending(id) {
  try {
    await deleteDoc(doc(_db, 'pending', id));
  } catch (e) {
    console.warn('[Firebase] fbDeletePending 실패:', e.message);
  }
}

/* ============================================================
   설정(settings) CRUD
  ============================================================ */

/** 설정 값 로드 */
export async function fbGetSetting(key) {
  try {
    const snap = await getDoc(doc(_db, 'settings', key));
    return snap.exists() ? snap.data().value : null;
  } catch (e) {
    console.warn('[Firebase] fbGetSetting 실패:', e.message);
    return null;
  }
}

/** 설정 값 저장 */
export async function fbSetSetting(key, value) {
  try {
    await setDoc(doc(_db, 'settings', key), { value });
  } catch (e) {
    console.warn('[Firebase] fbSetSetting 실패:', e.message);
  }
}

/* ============================================================
   내부 localStorage 폴백 함수
  ============================================================ */
function _localLoadJobs() {
  try {
    const raw = localStorage.getItem('construction_jobs');
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function _localSaveJob(job) {
  const jobs = _localLoadJobs();
  const idx  = jobs.findIndex(j => j.id === job.id);
  if (idx >= 0) jobs[idx] = job; else jobs.unshift(job);
  localStorage.setItem('construction_jobs', JSON.stringify(jobs));
}

function _localLoadPending() {
  try {
    const raw = localStorage.getItem('cj_pending_jobs');
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function _localSavePending(entry) {
  const list = _localLoadPending();
  list.unshift(entry);
  localStorage.setItem('cj_pending_jobs', JSON.stringify(list));
}

/* ── 외부 노출 (필요 시 직접 사용) ── */
export { _db as db, JOBS_COL, PENDING_COL, SETTINGS_COL };
